/* ترشی طلا — shared behavior: nav, reveals, drawer, tweaks */
(function () {
  /* ---------- nav scrolled state ---------- */
  var nav = document.querySelector('.nav');
  function onScroll() { if (nav) nav.classList.toggle('scrolled', window.scrollY > 8); }
  window.addEventListener('scroll', onScroll, { passive: true }); onScroll();

  /* ---------- mobile drawer ---------- */
  var burger = document.querySelector('.nav__burger');
  var drawer = document.querySelector('.drawer');
  var closeBtn = document.querySelector('.drawer__close');
  function setDrawer(open) {
    if (!drawer) return;
    drawer.classList.toggle('open', open);
    document.body.style.overflow = open ? 'hidden' : '';
  }
  if (burger) burger.addEventListener('click', function () { setDrawer(true); });
  if (closeBtn) closeBtn.addEventListener('click', function () { setDrawer(false); });
  if (drawer) drawer.querySelectorAll('a').forEach(function (a) { a.addEventListener('click', function () { setDrawer(false); }); });

  /* ---------- scroll reveal w/ stagger ---------- */
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -8% 0px' });
  document.querySelectorAll('[data-reveal]').forEach(function (el, i) {
    if (!el.style.getPropertyValue('--reveal-delay')) {
      var grp = el.getAttribute('data-reveal-group');
      if (grp) el.style.setProperty('--reveal-delay', (parseInt(grp, 10) * 90) + 'ms');
    }
    io.observe(el);
  });

  /* ================= TWEAKS ================= */
  var TWEAKS = /*EDITMODE-BEGIN*/{
    "gold": "#AE7A1C",
    "heroFont": "Lalezar",
    "bg": "cream",
    "motion": "smooth",
    "radius": 12
  }/*EDITMODE-END*/;

  // load saved overrides for cross-page consistency in preview
  try {
    var saved = JSON.parse(localStorage.getItem('tala_tweaks') || '{}');
    Object.assign(TWEAKS, saved);
  } catch (e) {}

  var GOLD_DEEP = { '#AE7A1C': '#8A5F12', '#A8551E': '#823F12', '#6E7C3A': '#535e27', '#9A3B57': '#742a40' };
  var GOLD_LIGHT = { '#AE7A1C': '#C9A24E', '#A8551E': '#C97A4A', '#6E7C3A': '#9aa766', '#9A3B57': '#c06a84' };

  function apply() {
    var r = document.documentElement;
    r.style.setProperty('--gold', TWEAKS.gold);
    r.style.setProperty('--gold-deep', GOLD_DEEP[TWEAKS.gold] || '#8A5F12');
    r.style.setProperty('--gold-light', GOLD_LIGHT[TWEAKS.gold] || '#C9A24E');
    r.style.setProperty('--radius', TWEAKS.radius + 'px');
    r.style.setProperty('--radius-sm', Math.max(4, TWEAKS.radius - 4) + 'px');
    var hf = TWEAKS.heroFont;
    r.style.setProperty('--font-hero', '"' + hf + '", "Vazirmatn", sans-serif');
    r.setAttribute('data-bg', TWEAKS.bg === 'deep' ? 'deep' : 'cream');
    r.setAttribute('data-motion', TWEAKS.motion === 'calm' ? 'calm' : (TWEAKS.motion === 'lively' ? 'lively' : 'smooth'));
  }
  apply();

  function persist() {
    try { localStorage.setItem('tala_tweaks', JSON.stringify(TWEAKS)); } catch (e) {}
    window.parent.postMessage({ type: '__edit_mode_set_keys', edits: TWEAKS }, '*');
  }

  /* ---- panel UI (built lazily) ---- */
  var panel = null;
  function field(label, html) {
    return '<div class="tw-field"><label class="tw-label">' + label + '</label>' + html + '</div>';
  }
  function swatches(name, opts, val) {
    return '<div class="tw-swatches">' + opts.map(function (o) {
      return '<button type="button" class="tw-sw' + (o === val ? ' on' : '') + '" data-k="' + name + '" data-v="' + o + '" style="background:' + o + '"></button>';
    }).join('') + '</div>';
  }
  function seg(name, opts, val) {
    return '<div class="tw-seg">' + opts.map(function (o) {
      return '<button type="button" class="tw-segbtn' + (o[0] === val ? ' on' : '') + '" data-k="' + name + '" data-v="' + o[0] + '">' + o[1] + '</button>';
    }).join('') + '</div>';
  }
  function build() {
    panel = document.createElement('div');
    panel.className = 'tw-panel';
    panel.innerHTML =
      '<div class="tw-head"><span>تنظیمات / Tweaks</span><button class="tw-x" type="button">×</button></div>' +
      '<div class="tw-body">' +
        field('رنگ طلایی', swatches('gold', ['#AE7A1C', '#A8551E', '#6E7C3A', '#9A3B57'], TWEAKS.gold)) +
        field('فونت تیتر', seg('heroFont', [['Lalezar', 'لاله‌زار'], ['Markazi Text', 'مرکزی'], ['Vazirmatn', 'وزیر']], TWEAKS.heroFont)) +
        field('پس‌زمینه', seg('bg', [['cream', 'کرم روشن'], ['deep', 'کرم تیره']], TWEAKS.bg)) +
        field('حرکت و انیمیشن', seg('motion', [['calm', 'آرام'], ['smooth', 'متعادل'], ['lively', 'سرزنده']], TWEAKS.motion)) +
        field('گردیِ گوشه‌ها — <span class="tw-val" id="twRad">' + TWEAKS.radius + 'px</span>', '<input type="range" class="tw-range" data-k="radius" min="0" max="22" step="2" value="' + TWEAKS.radius + '">') +
      '</div>';
    document.body.appendChild(panel);
    panel.querySelector('.tw-x').addEventListener('click', dismiss);
    panel.querySelectorAll('.tw-sw').forEach(function (b) {
      b.addEventListener('click', function () {
        TWEAKS.gold = b.dataset.v; apply(); persist();
        panel.querySelectorAll('.tw-sw').forEach(function (x) { x.classList.toggle('on', x === b); });
      });
    });
    panel.querySelectorAll('.tw-segbtn').forEach(function (b) {
      b.addEventListener('click', function () {
        TWEAKS[b.dataset.k] = b.dataset.v; apply(); persist();
        panel.querySelectorAll('.tw-segbtn[data-k="' + b.dataset.k + '"]').forEach(function (x) { x.classList.toggle('on', x === b); });
      });
    });
    var rng = panel.querySelector('.tw-range');
    if (rng) rng.addEventListener('input', function () {
      TWEAKS.radius = parseInt(rng.value, 10); apply();
      var v = document.getElementById('twRad'); if (v) v.textContent = TWEAKS.radius + 'px';
    });
    if (rng) rng.addEventListener('change', persist);
  }
  function show() { if (!panel) build(); panel.classList.add('open'); }
  function hide() { if (panel) panel.classList.remove('open'); }
  function dismiss() { hide(); window.parent.postMessage({ type: '__edit_mode_dismissed' }, '*'); }

  window.addEventListener('message', function (e) {
    var t = e.data && e.data.type;
    if (t === '__activate_edit_mode') show();
    else if (t === '__deactivate_edit_mode') hide();
  });
  window.parent.postMessage({ type: '__edit_mode_available' }, '*');
})();